"""Domain models for ScamShield."""
