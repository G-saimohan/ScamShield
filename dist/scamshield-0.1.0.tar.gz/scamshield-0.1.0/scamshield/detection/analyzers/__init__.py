"""Detection analyzer modules."""
